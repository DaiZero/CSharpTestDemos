﻿using System.Windows;

namespace WpfApp_TestDemo.Views
{
    /// <summary>
    /// Window_cnblogsDemo.xaml 的交互逻辑
    /// </summary>
    public partial class Window_cnblogsDemo : Window
    {
        public Window_cnblogsDemo()
        {
            InitializeComponent();
        }
    }
}
